// Toggle mobile navigation
document.addEventListener('DOMContentLoaded', function() {
  const navToggle = document.querySelector('.nav-toggle');
  const mainNav = document.querySelector('.main-nav');

  if (navToggle && mainNav) {
    navToggle.addEventListener('click', function() {
      mainNav.classList.toggle('active');
    });
  }

  // Share button functionality
  const shareBtns = document.querySelectorAll('.share-btn');

  shareBtns.forEach(btn => {
    btn.addEventListener('click', function() {
      const url = window.location.href;
      const title = document.querySelector('h1').textContent;

      if (this.classList.contains('facebook')) {
        window.open(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}`, '_blank');
      } else if (this.classList.contains('twitter')) {
        window.open(`https://twitter.com/intent/tweet?url=${encodeURIComponent(url)}&text=${encodeURIComponent(title)}`, '_blank');
      } else if (this.classList.contains('email')) {
        window.location.href = `mailto:?subject=${encodeURIComponent(title)}&body=${encodeURIComponent(url)}`;
      } else if (this.classList.contains('copy')) {
        navigator.clipboard.writeText(url)
          .then(() => {
            alert('Link copied to clipboard!');
          })
          .catch(err => {
            console.error('Could not copy text: ', err);
          });
      }
    });
  });
});
